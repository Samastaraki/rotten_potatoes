import 'package:flutter/material.dart';
import 'package:rotten_potatoes/utill/colorR.dart';

import 'login_screen.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({Key? key}) : super(key: key);

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Padding(
          padding: const EdgeInsets.only(top: 100, bottom: 30),
          child: Center(
              child: Column(
            // textDirection: TextDirection.rtl,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Text('ساخت حساب کاربری',
                  style: TextStyle(fontSize: 30, fontFamily: 'iransans')),
              Padding(
                padding: const EdgeInsets.only(top: 50, bottom: 50),
                child: Column(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                          color: ColorR.field,
                          borderRadius: BorderRadius.all(Radius.circular(20))),
                      width: MediaQuery.of(context).size.width * 0.7,
                      child: TextFormField(
                        textInputAction: TextInputAction.next,
                        style: TextStyle(
                            fontFamily: 'iransans', color: Colors.white),
                        // textDirection: TextDirection.rtl,
                        decoration: InputDecoration(
                            // hintTextDirection: TextDirection.rtl,
                            border: OutlineInputBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(20))),
                            hintText: 'نام مستعار',
                            hintStyle: TextStyle(fontFamily: 'iransans')),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      decoration: BoxDecoration(
                          color: ColorR.field,
                          borderRadius: BorderRadius.all(Radius.circular(20))),
                      width: MediaQuery.of(context).size.width * 0.7,
                      child: TextFormField(
                        textInputAction: TextInputAction.next,
                        style: TextStyle(
                            fontFamily: 'iransans', color: Colors.white),
                        textDirection: TextDirection.ltr,
                        decoration: InputDecoration(
                            border: OutlineInputBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(20))),
                            hintText: 'نام کاربری',
                            hintStyle: TextStyle(fontFamily: 'iransans')),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      decoration: BoxDecoration(
                          color: ColorR.field,
                          borderRadius: BorderRadius.all(Radius.circular(20))),
                      width: MediaQuery.of(context).size.width * 0.7,
                      child: TextFormField(
                        textInputAction: TextInputAction.next,
                        obscureText: true,
                        style: TextStyle(
                            fontFamily: 'iransans', color: Colors.white),
                        textDirection: TextDirection.ltr,
                        decoration: InputDecoration(
                            border: OutlineInputBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(20))),
                            hintText: 'رمز عبور',
                            hintStyle: TextStyle(fontFamily: 'iransans')),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      decoration: BoxDecoration(
                          color: ColorR.field,
                          borderRadius: BorderRadius.all(Radius.circular(20))),
                      width: MediaQuery.of(context).size.width * 0.7,
                      child: TextFormField(
                        obscureText: true,
                        style: TextStyle(
                            fontFamily: 'iransans', color: Colors.white),
                        textDirection: TextDirection.ltr,
                        decoration: InputDecoration(
                            border: OutlineInputBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(20))),
                            hintText: 'تکرار رمز عبور',
                            hintStyle: TextStyle(fontFamily: 'iransans')),
                      ),
                    ),
                  ],
                ),
              ),
              Column(
                children: [
                  ElevatedButton(
                    onPressed: () {},
                    child: Text(
                      'ثبت نام',
                      style: TextStyle(fontFamily: 'iransans'),
                    ),
                    style: ElevatedButton.styleFrom(
                      minimumSize:
                          Size(MediaQuery.of(context).size.width * 0.6, 50),
                      primary: ColorR.text,
                      onPrimary: Colors.white,
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  TextButton(
                      onPressed: () {
                        Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                              builder: (context) => LoginScreen(),
                            ));
                      },
                      child: Text(
                        'از قبل حساب کاربری دارید؟',
                        style: TextStyle(fontFamily: 'iransans'),
                      )),
                ],
              )
            ],
          )),
        ),
      ),
    );
  }
}
