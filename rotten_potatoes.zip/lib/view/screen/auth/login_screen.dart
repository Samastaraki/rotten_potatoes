import 'package:flutter/material.dart';
import 'package:rotten_potatoes/utill/colorR.dart';
import 'package:rotten_potatoes/view/screen/auth/signup_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Padding(
          padding: const EdgeInsets.only(top: 100, bottom: 30),
          child: Center(
              child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Text('ورود به حساب',
                  style: TextStyle(fontSize: 30, fontFamily: 'iransans')),
              Padding(
                padding: const EdgeInsets.only(top: 50, bottom: 50),
                child: Column(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                          color: ColorR.field,
                          borderRadius: BorderRadius.all(Radius.circular(20))),
                      width: MediaQuery.of(context).size.width * 0.7,
                      child: TextFormField(
                        textInputAction: TextInputAction.next,
                        style: TextStyle(
                            fontFamily: 'iransans', color: Colors.white),
                        textDirection: TextDirection.ltr,
                        decoration: InputDecoration(
                            border: OutlineInputBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(20))),
                            hintText: 'نام کاربری',
                            hintStyle: TextStyle(fontFamily: 'iransans')),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      decoration: BoxDecoration(
                          color: ColorR.field,
                          borderRadius: BorderRadius.all(Radius.circular(20))),
                      width: MediaQuery.of(context).size.width * 0.7,
                      child: TextFormField(
                        style: TextStyle(
                            fontFamily: 'iransans', color: Colors.white),
                        obscureText: true,
                        textDirection: TextDirection.ltr,
                        decoration: InputDecoration(
                            border: OutlineInputBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(20))),
                            hintText: 'رمز عبور',
                            hintStyle: TextStyle(fontFamily: 'iransans')),
                      ),
                    ),
                  ],
                ),
              ),
              Column(
                children: [
                  ElevatedButton(
                    onPressed: () {},
                    child: Text(
                      'ورود',
                      style: TextStyle(fontFamily: 'iransans'),
                    ),
                    style: ElevatedButton.styleFrom(
                      minimumSize:
                          Size(MediaQuery.of(context).size.width * 0.6, 50),
                      primary: ColorR.text,
                      onPrimary: Colors.white,
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  TextButton(
                      onPressed: () {
                        Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                              builder: (context) => SignupScreen(),
                            ));
                      },
                      child: Text(
                        'کاربر جدید هستید؟ اینجا را کلیک کنید.',
                        style: TextStyle(fontFamily: 'iransans'),
                      )),
                ],
              ),
            ],
          )),
        ),
      ),
    );
  }
}
