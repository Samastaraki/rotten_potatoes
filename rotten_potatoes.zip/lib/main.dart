import 'package:flutter/material.dart';
import 'package:rotten_potatoes/utill/colorR.dart';
import 'package:rotten_potatoes/view/screen/auth/auth_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Rotten Potatoes',
      theme: ThemeData(
        scaffoldBackgroundColor: ColorR.background,
        // appBarTheme: AppBarTheme(color: kPrimaryColor),
        primaryColor: ColorR.text,
        textTheme: Theme.of(context).textTheme.apply(bodyColor: ColorR.text),
      ),
      // home: AuthScreen(),
      home:
          Directionality(textDirection: TextDirection.rtl, child: AuthScreen()),
    );
  }
}
