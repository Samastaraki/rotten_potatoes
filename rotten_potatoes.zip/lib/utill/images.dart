class Images {
  static const String auth = 'assets/image/auth.png';
  static const String auth3 = 'assets/image/auth3.png';
}
