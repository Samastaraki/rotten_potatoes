import 'package:flutter/cupertino.dart';

class ColorR {
  static Color background = Color(0xff18171F);
  static Color text = Color(0xff7900FF);
  static Color field = Color(0xff3e4759);
}
