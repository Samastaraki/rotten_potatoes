package com.example.rotten_potatoes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
